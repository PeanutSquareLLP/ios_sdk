//
//  SparkLib.h
//  SparkLib
//
//  Created by alexeym on 19/03/2018.
//  Copyright © 2018 Hola. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SparkLib.
FOUNDATION_EXPORT double SparkLibVersionNumber;

//! Project version string for SparkLib.
FOUNDATION_EXPORT const unsigned char SparkLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SparkLib/PublicHeader.h>

#import "spark_api.h"
#import "spark_api_interface.h"
